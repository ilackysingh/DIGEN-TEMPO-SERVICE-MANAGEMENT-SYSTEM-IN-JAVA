/**
 *
 * @author LUCKY SINGH
 */
import java.sql.*;              
public class database {
    private Connection conn;  
    private Statement stmt;
    private ResultSet rset;
                    
    public database () throws ClassNotFoundException {  
        try {                   
            Class.forName ("org.apache.derby.jdbc.ClientDriver"); 
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/tempo");
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            DatabaseMetaData aboutDB = conn.getMetaData(); 
            String [] tableType = {"TABLE"};
            
            { 
                String [] SQL = initListingsTable();
                for (int i=0; i < SQL.length; i++) 
                {
                    stmt.execute(SQL[i]);
                }
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
                    
    private String [] initListingsTable() {
        String[]  SQL = {
            "create table lucky (" +
            "BOOKING_NO  varchar(5) ,"+    
            "DATE  varchar (16)," +
            "TEMPO_NAME varchar (16)," +
            "FLEET_SIZE  varchar(16)," +
            "CONTACT_NO varchar(10)," +
            "JOURNEY varchar(15)," +
            "primary key(BOOKING_NO))" ,
            "insert into lucky values ('1','25-5-2020', 'ANDERSON', '10',  '8250326632', 'SINGLE')",
            "insert into lucky values ('2','25-5-2020', 'CABLES',   '23', '4340326632', 'SINGLE')",
            "insert into lucky values ('3','25-5-2020', 'FRY',      '26', '5420326632', 'SINGLE')",
            "insert into lucky values ('4','25-5-2020', 'MARTIN',   '56', '6620326632', 'SINGLE')",
            "insert into lucky values ('5','25-5-2020', 'TUCKER',   '07',  '6960326632', 'SINGLE')",
        };
        return SQL;
    } 
}